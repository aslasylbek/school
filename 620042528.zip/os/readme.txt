in the command line presented, type the command help to see the functions

The code that is given is used to create a process model which can lead to a deadlock scenario. This programs allows the gives the user full control of creating and destroying process as well as assigning resources to process.

After creation and mapping of all the processes and resources which the user wants, the user will be able to run an animation of the process model to see the flow of processes.
If there is a deadlock in the process model, the system should trace the deadlock and suggest the relevant tools the user can user to destroy the dead lock

NB. deadlock avoidance and so will be implemented as well. However, this will take time and a bit more consideration. Therefore I am requesting additional time considering the fact that I'm building a API as well as you can tell by the use of the terminal and raw object orientated programming in JavaScript

Student...
Oshane Bailey
620042528